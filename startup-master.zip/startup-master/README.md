# HTML5 BootCamp base folders layout

Please, use this repository as a base for you training phase. The idea is
to fork this project so everyone uses the same folder structure for the
exercises.

It's extremely important to keep the key points easy to be verified by
the reviewers, so **don't mix the key points with the rest of the
exercises**
